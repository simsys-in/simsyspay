export const config = {
  apiUrl: 'http://erp4.simsys.org/api/',
  loginsts:false,
  token:''
};