//this is the final file should be compiled for the live production or dev server
export const environment = {
  production: true
};
