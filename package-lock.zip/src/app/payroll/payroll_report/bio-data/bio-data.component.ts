import { Component, OnInit, Input } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { config } from 'src/app/config';
import { FormGroup, FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';

class Employees{
public employee : string;
public employee_code : string;
address : any;
}
@Component({
  selector: 'app-bio-data',
  templateUrl: './bio-data.component.html',
  styleUrls: ['./bio-data.component.scss']
})
export class BioDataComponent implements OnInit {
employees:any;
@Input() emp_info:any;
@Input() employee_experiences:any;
filteredEmployees:any;
headForm:FormGroup

httpOptions = {
  headers: new HttpHeaders({
  'Content-Type':  'application/json',
  'Authorization': localStorage.token,
  })
  }
    constructor(private http:HttpClient) {
   }

  ngOnInit() {
    this.headForm=new FormGroup ( {
 from_date:new FormControl(''),
 to_date:new FormControl(''),
      employee:new FormControl(''),
      employee_id:new FormControl(''),
 
        });

    this.http.get(config.apiUrl+'payroll/employee',this.httpOptions).subscribe(res =>{
      this.employees = res;
      this.filteredEmployees = this.headForm.controls.employee.valueChanges
      .pipe(startWith(''),
        map(lg => lg?this.employees.filter(employees => employees.employee.toLowerCase().indexOf(lg.toLowerCase()) >= 0) : this.employees.slice())
      );
      });

    }

    ngAfterViewInit() {
      (document.querySelector('.example-sidenav-container') as HTMLElement).style.height = 'auto';
      (document.querySelector('.example-sidenav-container') as HTMLElement).style.overflow = 'visible';
  }
 employeeSelect(employeeInfo){
    this.headForm.controls.employee_id.setValue(employeeInfo.id);
}

  simsView(id){

let p={
  from_date:'this.from_date',
  to_date:'this.to_date',
  employee_code:'this.employee_code',
}

    this.http.post<any>(config.apiUrl+'payroll/payroll_report/timecard_compliance',p,this.httpOptions).subscribe(
    res => {
    console.table(res);
        this.emp_info=res;
 
    },
    error => {
    alert(error);
    });
  }
  onPrint(){
    window.print();
  
}
}