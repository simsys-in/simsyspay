import { Component, OnInit, Input } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { FormBuilder } from '@angular/forms';
import { config } from 'src/app/config';
@Component({
  selector: 'app-attendance-compliance',
  templateUrl: './attendance-compliance.component.html',
  styleUrls: ['./attendance-compliance.component.scss']
})
export class AttendanceComplianceComponent implements OnInit {
 
  httpOptions = {
    headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': localStorage.token,
    })
    }
empArr:any;
 @Input() emp_info:any;
    res:any;
  constructor(
    private http: HttpClient,
private route:ActivatedRoute,
private snackBar: MatSnackBar,
private fb: FormBuilder
  ) { }
isForm=true;
  ngOnInit() {
let emp_info=this.res;
  }


}
