import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceComplianceComponent } from './attendance-compliance.component';

describe('AttendanceComplianceComponent', () => {
  let component: AttendanceComplianceComponent;
  let fixture: ComponentFixture<AttendanceComplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendanceComplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendanceComplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
