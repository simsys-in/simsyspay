import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router'
import { config } from 'src/app/config';

import * as moment from 'moment';
@Component({
selector: 'app-punch-log-betweendate',
templateUrl: './punch-log-betweendate.component.html',
styleUrls: ['./punch-log-betweendate.component.scss']
})
export class PunchLogBetweenDateComponent implements OnInit {

isForm = true;
httpOptions = {
headers: new HttpHeaders({
'Content-Type':  'application/json',
'Authorization': localStorage.token,
})
}
form:any={

};

formState:String;
s:any={
h:{

from_date:moment().format(),
to_date:moment().format(),

},
i:{}

};
options: FormGroup;
    shift_count: any;
    id: any;
    

constructor(
private router:Router,
private http: HttpClient,
private routes:ActivatedRoute,
private fb:FormBuilder

) { this.options = fb.group({
hideRequired: false,
floatLabel: 'auto',

});



}

ngOnInit() {

}

simsPrint(){
window.print();
}




query_detail(){
    this.formState='list';
let p = this.s.h;
p.from_date = moment(this.s.h.from_date).format('YYYY/MM/DD');
p.to_date = moment(this.s.h.to_date).format('YYYY/MM/DD');

this.http.post<any>(config.apiUrl+'payroll/payroll_report/log_between_group_employee',p,this.httpOptions).subscribe(res =>{
this.s.i=res;

},
error=>{
console.log(error);
}
);

} 
load(){
    
    let data=this.id;
   console.table(data);
   this.routes.navigate(['/payroll/employee'],{
       queryparams:{data:JSON.stringify(data)
    
    }
   })
}


}


