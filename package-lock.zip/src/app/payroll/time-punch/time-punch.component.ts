import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatTableDataSource, SimpleSnackBar } from '@angular/material';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { config } from 'src/app/config';
import { startWith, map } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';


@Component({
selector: 'app-time-punch',
templateUrl: './time-punch.component.html',
styleUrls: ['./time-punch.component.scss']
})

export class TimePunchComponent implements OnInit {
options: FormGroup;


f:any={
h:{
  logDate:'',
employee:'',
employee_code:'',
id:'',
},


};

employees: any;
filteredEmployees: any;

httpOptions = {
headers: new HttpHeaders({
'Content-Type':  'application/json',
'Authorization': localStorage.token,
})
}


users:any;


formState: string;

constructor(
fb: FormBuilder,
private http:HttpClient,
private routes:Router,
private snackBar: MatSnackBar,

) {
this.options = fb.group({
hideRequired: false,
floatLabel: 'auto',
});

this.http.get<any>(config.apiUrl+'payroll/employee',this.httpOptions).subscribe(res =>{
  //if (res.status =='token_expired') return this.routes.navigate(['logout']);
  this.employees = res;
})

}
ngOnInit() {
this.simsNew();
}


employeeFilter(typing){
  this.filteredEmployees= (typeof(typing) != 'object')?this.employees.filter(row => row.employee.toLowerCase().indexOf(typing.toLowerCase()) >= 0) : this.employees.slice()
  }
  
  employeeSelect(ac){
  let row = ac.option.value;
  this.f.h.employee_code=row.employee_code;
  this.f.h.employee=row.employee;
  }



simsSave(){
let p = this.f.h;
this.formState='form';
this.http.post<any>(config.apiUrl+'payroll/device_logs',p,this.httpOptions).subscribe(res =>{
if (res.status =='token_expired') return this.routes.navigate(['logout']);
this.snackBar.open('Insert Successfully id.'+res.id,"Insert",{duration: 5 * 1000,});
this.simsNew();
},
error=>{
 console.log(error);
});   
}

simsNew(){
  this.formState='form';
  
  this.f={
  h:{
  employee:'',
  employee_code:'',
  logDate:'',
  id:'',
  },
  
  }
  
  }


}